************ READ ME ************ 

The Ticket to Ride Travel Agency's Flight reservation system.

An GUI menu driven application that gives the user the following options:

- Find a flight using the originating airport, destination airport, and a day of the week the flight is departing;
- Make a flight reservation for a traveler;
- Find existing flight reservations using the reservation code, airline, and traveler name;
- An existing flight reservation can be modified. The travelers name and citizenship can be updated
- An existing flight reservation can be modified. The travelers name and citizenship can be updated.
- An existing flight reservation can be soft-deleted (still exist in the base, but not in the search or smtg) , marking it as inactive and freeing up a seat on the flight.



Viktoriia Davydova, June 26, 2019


To run the application in the terminal, type java -jar V_Davydova3.jar.

